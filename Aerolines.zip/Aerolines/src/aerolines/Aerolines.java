package aerolines;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Aerolines extends JFrame {

    private static Aerolines aerolines_aerolines;
    private static Image egipt;
    private static Image helicopter;
    private static Image plane;
    private static Image runway;  
    private static double plane_x = 100;  
    private static double plane_y = 500;  
    private static long last_frame_time;


    public static void main(String[] args) throws IOException {
       
        egipt = ImageIO.read(Aerolines.class.getResourceAsStream("egipt.jpg"));
        helicopter = ImageIO.read(Aerolines.class.getResourceAsStream("helikopter.png"));
        plane = ImageIO.read(Aerolines.class.getResourceAsStream("plane.png"));
        runway = ImageIO.read(Aerolines.class.getResourceAsStream("vpp1.jpeg")); 

       
        aerolines_aerolines = new Aerolines();
        aerolines_aerolines.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        aerolines_aerolines.setLocation(200, 50);
        aerolines_aerolines.setSize(900, 600);
        aerolines_aerolines.setResizable(false);

        last_frame_time = System.nanoTime();

        
        AerolinesField aerolines_field = new AerolinesField();
        aerolines_aerolines.add(aerolines_field);
        aerolines_aerolines.setVisible(true);
    }

    
    public static void onRepaint(Graphics g) {
        long current_time = System.nanoTime();
        float delta_time = (current_time - last_frame_time) * 0.000000001f;
        last_frame_time = current_time;

       
        plane_x += delta_time * 100; 
        plane_y -= delta_time * 22;  
        if (plane_x > 900 || plane_y < -100) {
            plane_x = 100; 
            plane_y = 800;  
        }

        
        g.drawImage(egipt, 0, 0, 900, 600, null); 
        g.drawImage(helicopter, 20, 20, 120, 60, null);
        g.drawImage(runway, 0, 500, 900, 100, null);
        g.drawImage(plane, (int) plane_x, (int) plane_y, 100, 50, null);
    }


    public static class AerolinesField extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            onRepaint(g);
            repaint();  
        }
    }
}
